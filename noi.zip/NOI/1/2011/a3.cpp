#include <iostream>
#include <cmath>
#include <windows.h>
using namespace std;
void solve(int a)
{
int r=0;
int start=sqrt(a);
int ch=0;
    for(int i=start;i>=1;i--)
    {
        for(int j=i-1;j>=1;j--)
        {
            if(a==i*i*i-j*j*j)
            {
                ch=1;
                cout <<i<<" "<<j<<endl;
                i=1;
              //  exit(0);
            }

        }
    }
if(ch==0)cout<<"NO"<<endl;
}
int main()
{
    int a,b;
    cin>>a;
    cin>>b;
    solve(a);
    solve(b);
    return 0;
}
