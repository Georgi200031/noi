#include <iostream>
using namespace std;
char s[1001][1001];

int main()
{
    int n,m,r,c;
    cin>>n>>m;
    cin>>r>>c;
    for(int i=1;i<=n;i++)
    {
        cin>>s[i];
    }
    int flag=0;
    int answer=0;
    for(int i=1;i+r<=n;i++)
    {
        for(int j=1;j+c<=m;j++)
        {
            flag=1;
            for(int ii=1;ii<=r;ii++)
                for(int jj=1;jj<=c;jj++)
                {
                    if(s[i+ii][j+jj]=='#')flag=0;
                }
                answer=answer+flag;
        }
    }
    cout<<answer<<endl;
    return 0;
}
