#include <iostream>
#define MAXN 9999999
using namespace std;
int x[MAXN],y[MAXN],z[MAXN];
int ans1(int n)
{
    int ans=0;
    for(int i=1;i<=n;i++)
    {
        for(int j=i+1;j<=n;j++)
        {
            if(x[i]*y[j]==x[j]*y[i])
            {
                ans++;
            }
        }
    }
    return ans;
}
int ans2(int n)
{
      int ans=0;
    for(int i=1;i<=n;i++)
    {
        for(int j=i+1;j<=n;j++)
        {
            if(x[i]*y[j]==x[j]*y[i] && x[i]*z[j]==x[j]*z[i] &&  y[i]*z[j]==y[j]*z[i])
            {
                ans++;
            }
        }
    }
    return ans;
}
int main()
{
    int n,ans=0;
    cin>>n;
    for(int i=1;i<=n;i++)
    {
        cin>>x[i]>>y[i]>>z[i];
    }
    cout<<ans1(n)<<endl;
    cout<<ans2(n)<<endl;
    return 0;
}
