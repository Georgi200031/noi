#include <iostream>
using namespace std;
int solve(long long a)
{
int aa,bb;
long long j=1;
int jj;
int j1;
int answer=1;
int res_1=0,res_2=0;
    for(int i=1;i<=a/2;i++)
    {
        answer=0;
        res_1=0;
        res_2=0;
        aa=a-i;

       // cout<<aa<<" "<<i<<endl;
        //----------------------------------------------------------------------------------------------------
        j1=aa;
        j=1;
        while(j1>9)
        {
            jj=aa/j %10;
            j=j*10;
            j1=j1/10;
            if(jj==0 || jj==1 || jj==2)
                res_1=1;


        }
        //cout<<j1<<endl;
        if(j1==0 || j1==1 || j1==2)res_1=1;

        //------------------------------------------------------------------------------------------------------
if(res_1==0)
{
        j1=i;
        j=1;
        while(j1>9)
        {
            jj=i/j %10;
            j=j*10;
            j1=j1/10;
            if(jj==0 || jj==1 || jj==2)
                res_2=1;
            //cout<<jj<<endl;
        }
        //cout<<j1<<endl;
        if(j1==0 || j1==1 || j1==2)res_2=1;
}
        if(res_1==1 || res_2==1)
        {
            answer=1;
        }
        if(res_1==0 && res_2==0)
        {

            answer=0;
            i=a;
        }
       // cout<<":::::::"<<res_1<<" "<<res_2<<endl;

    }
    return answer;
}
int main()
{
    long long a,b,c;
    cin>>a;
    cin>>b;
    cin>>c;
    cout<<solve(a)<<endl;
    cout<<solve(b)<<endl;
    cout<<solve(c)<<endl;
    return 0;
}
