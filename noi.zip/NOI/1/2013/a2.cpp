#include<iostream>
#include<set>
using namespace std;

int x1, y1, x2, y2, a, b;
set<int> s;

int main()
{
  cin >> x1 >> y1 >> x2 >> y2 >> a >> b;
  //      1     1     2     2    4    4
  int c=0;
  for(int i1=1;i1<a;i1++)
    for(int j1=1;j1<b;j1++)//endna tochka
        for(int i2=1;i2<a;i2++)
            for(int j2=1;j2<b;j2++)//vtora tochka

                if((i1!=i2)||(j1!=j2))//ashtoto da ne e otsechka

                    if((x1-x2)*(i1-i2)+(y1-y2)*(j1-j2)==0)
                        {
                            c++;
                            int d = (i1-i2)*(i1-i2)+(j1-j2)*(j1-j2);
                            s.insert(d);
                        }
  cout << c/2 << " " << s.size() << endl;
}

