#include <iostream>
using namespace std;
char buf[64];
bool isCorrect(const char *e)
{
    bool op1=false,op2=false;
    for (int i=0;e[i];i++)
        {
            switch (e[i])
                {
      case '(':{if (op2) return false;
             op2=!op2; break;
            }
   case ')':{if (!op2) return false;
             op2=!op2; break;
            }
   case '[':{if (op1 || op2) return false;
             op1=!op1; break;
            }
   case ']':{if (!op1 || op2) return false;
             if (e[i-1]!=')') return false;
             op1=!op1;
            }
  }
 }
 return !(op1 || op2);
}
int main()
{ for (int i=0;i<4;i++)
  {cin>>buf;
   cout<<isCorrect(buf)<<endl;
  }
  return 0;
}
