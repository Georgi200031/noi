#include <iostream>
#include <cmath>
#include <cstdio>

using namespace std;

int mMin,mMax,N,a[200001],b[200001],c[200001];

int main() {
int i,k,r;
    scanf("%d",&N);
	for (i=1; i<=N; i++) scanf("%d", &a[i]);

	k=0;
	if (a[N]>0)   k=1;
	mMax=a[N];
	// mMin=N;
	mMin=a[N];
	if (N-a[N]==1) r=1;
	  else
	  r=0;
	  c[N]=a[N];
	for (i=N-1; i>=1; i--){
	    b[i]=k;
	    if (mMax<b[i]+a[i])
	    	mMax=b[i]+a[i];
	    if (a[i]>0)  k++;
	    c[i]=a[i]+r;
	    if (mMin>c[i]) mMin=c[i];
	    if (i-a[i]==1) r++;
   }

	cout<<mMax<<endl<<mMin<<endl;
    return 0;
}
