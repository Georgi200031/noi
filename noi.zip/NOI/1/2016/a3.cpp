#include <iostream>
#define MAXN 999999
using namespace std;
int a[MAXN];
int b[MAXN];
int gol[MAXN];
int gol1[MAXN];
int h=1;
int solve_max(int n)
{
	int maxn=0;
	int minn=999999;
	int k;
		for(int i=1;i<=n;i++)
			b[i]=a[i];
		for(int i=1;i<=n;i++)
		{
			k=a[i];
			for(int j=i-k;j<i;j++)
				{

					if(k!=0)
						{
							k--;
							a[j]++;
						}
				}
		}
		for(int i=1;i<=n;i++)
		{
			if(maxn<a[i])maxn=a[i];
			if(minn>a[i])minn=a[i];
			//cout<<a[i]<<" ";
		}
		cout<<endl;
		gol[h]=maxn;
		gol1[h]=minn;
		h++;
		for(int i=1;i<=n;i++)
			a[i]=b[i];

	
	return maxn;
}	
int main()
{
	int n;
	cin>>n;
	for(int i=1;i<=n;i++)
	{
		cin>>a[i];
	}
	int c=0;
	int d=solve_max(n);
	for(int i=1;i<=h;i++)
	{
		if(gol[i]==d)
		{
		//	cout<<d<<endl;
			c=gol1[i];	
		}
	}
	cout<<d<<endl<<c<<endl;
	return 0;
}
