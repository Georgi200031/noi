#include <iostream>
#include <vector>
using namespace std;
vector<int>sums;
struct {long long int x, y, value;} d[10001];
int p=0;

bool empty(long long int x, long long int y)
{
  for(int i=1;i<=p;i++)
   if((d[i].x==x)&&(d[i].y==y)) return false;
  return true;
}
int sum(long long int x, long long int y)
{
  if(!empty(x,y)) return 0;
  int s=0;
  for(int i=1;i<=p;i++)
   {
     if(((d[i].x==x)&&(d[i].y==y+1))||
        ((d[i].x==x)&&(d[i].y==y-1))||
        ((d[i].y==y)&&(d[i].x==x+1))||
        ((d[i].y==y)&&(d[i].x==x-1)))
          s += d[i].value;
  }
  return s;
}
int main()
{
    int k,x,y,value;
    cin>>k;
    int f;
    for(int i=1;i<=k;i++)
    {
        f=0;
        cin>>x>>y>>value;
        for(int j=0;j<=p;j++)
        if(d[j].x==x && d[j].y==y)
        {
            f=1;
            d[j].value=d[j].value+value;
            break;
        }
        p++;
        if(f==0)
        {
            d[i].x=x;
            d[i].y=y;
            d[i].value=value;
        }
    }
    int ms=0;
    for(int j=1;j<=p;j++)
   {
     long long int x=d[j].x;
     long long int y=d[j].y;

     if(y+1<1000001) ms=max(ms,sum(x, y+1));
     if(y-1>0)ms=max(ms,sum(x, y-1));
     if(x+1<1000001)ms=max(ms,sum(x+1,y));
     if(x-1>0) ms=max(ms,sum(x-1,y));
   }
   cout << ms << endl;
    return 0;
}
/*
6
1 1 1
1 1 1
2 1 3
2 1 4
5 6 9
6 5 8
*/
