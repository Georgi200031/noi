#include <iostream>
#include <string>
#include <algorithm>
#define MAXN 999999
using namespace std;
int a[MAXN];
string ans;
bool used[1001];
string check(int n)
{
    int ch=0;
//-----------------------------------------
    for(int i=2;i<=n;i++)
    {
	if(a[i]==a[i-1])ch++;    
    }
    if(ch==4)
    {
	ans="Impossible";
    }
//-----------------------------------------
if(ans.size()==0)
{
    ch=0;
    int k=1;
    for(int i=1;i<=n;i++)
    {
         for(int j=1;j<=n;j++)
	 {
		if(i!=j)
		{
			if(a[i]==a[j])ch++;	
			 
		}
	 }
    	 if(ch==3)
    		{
			ans="Four of a Kind";
    		}
	 ch=0;
    }
}
//---------------------------------------
if(ans.size()==0)
{

    ch=0;
    for(int i=1;i<=n;i++)
    {
	for(int j=i+1;j<=n;j++)
	{
		if(a[i]==a[j])
		{
		     for(int i1=1;i1<=n;i1++)
			{
				for(int j1=i1+1;j1<=n;j1++)
				{	
					if(i1!=i && j1!=j && j1!=i && i1!=j)
						if(a[i1]==a[j1])ch++;
				}
				if(ch==2)ans="Full House";
				ch=0;
   			}
		}
    	    
	}
   }
}
//-------------------------------------
if(ans.size()==0)
{	
ch=0;
    int b[1001];
    for(int i=1;i<=n;i++)
    {
	b[i]=a[i];
    }
    sort(b,b+6);
    for(int i=1;i<=n;i++)
    {
	if(b[i]==b[i+1]-1)ch++;
    }
    if(ch==4)
    {
	ans="Straight";
    }
}
//-------------------------------------
if(ans.size()==0)
{
ch=0;
    for(int i=1;i<=n;i++)
    {
	for(int j=i+1;j<=n;j++)
	{
		for(int h=j+1;h<=n;h++)
		{
			if(a[i]==a[j]&& a[j]==a[h])ch=1;
		}
	}
    }
    if(ch==1)
    {
	ans="Three of a Kind";
    }
}
//-------------------------------------
if(ans.size()==0)
{	
ch=0;
    for(int i=1;i<=n;i++)
    {
	for(int j=i+1;j<=n;j++)
	{
		if(a[i]==a[j])
		{
			for(int i1=1;i1<=n;i1++)
			{
				for(int j1=i1+1;j1<=n;j1++)
				{
					if(i!=i1 && j!=j1 && i!=j1 && j!=i1)
					{
						if(a[i1]==a[j1])ch=1;
					}
				}
				
			}
			if(ch==1)
			{
				ans="Two Pair";
			}
		}
	}
    }
}
//-------------------------------------
if(ans.size()==0)
{
	for(int i=1;i<=n;i++)
	{
		for(int j=i+1;j<=n;j++)
		{
			if(a[i]==a[j])
			{
				ans="One Pair";
			}
		}
	}
	
}
if(ans.size()==0)ans="Nothing";
    return ans;
}
int main()
{
	int n=5;
	for(int i=1;i<=n;i++)
	{
		cin>>a[i];
	}
	cout<<check(n)<<endl;
	return 0;
}
