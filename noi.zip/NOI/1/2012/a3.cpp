#include <iostream>
#include <math.h>
#define MAXX 999999
using namespace std;
const int n=4;
int x[MAXX],y[MAXX];
int pow_2(int sum)
{
    return sum*sum;
}
int abc()
{
    int ab,bc,ac,S,p;
    ab=sqrt(pow_2(x[2]-x[1])+pow_2(y[2]-y[1]));
    bc=sqrt(pow_2(x[3]-x[2])+pow_2(y[3]-y[2]));
    ac=sqrt(pow_2(x[3]-x[1])+pow_2(y[3]-y[1]));
    p=(ab+bc+ac)/2;
    S=sqrt(p*(p-ab)*(p-bc)*(p-ac));
    return S;
}
int bcd()
{
    int bc,bd,cd,S,p;
    bc=sqrt(pow_2(x[3]-x[2])+pow_2(y[3]-y[2]));
    bd=sqrt(pow_2(x[4]-x[2])+pow_2(y[4]-y[2]));
    cd=sqrt(pow_2(x[4]-x[3])+pow_2(y[4]-y[3]));
    p=(bc+bd+cd)/2;
    S=sqrt(p*(p-bd)*(p-bc)*(p-cd));
    return S;
}
int acd()
{
    int ac,ad,cd,S,p;
    ac=sqrt(pow_2(x[3]-x[1])+pow_2(y[3]-y[1]));
    ad=sqrt(pow_2(x[4]-x[1])+pow_2(y[4]-y[1]));
    cd=sqrt(pow_2(x[4]-x[3])+pow_2(y[4]-y[3]));
    p=(ac+ad+cd)/2;
    S=sqrt(p*(p-ac)*(p-ad)*(p-cd));
    return S;
}
int abd()
{
    int ab,bd,ad,S,p;
    ab=sqrt(pow_2(x[2]-x[1])+pow_2(y[2]-y[1]));
    bd=sqrt(pow_2(x[4]-x[2])+pow_2(y[4]-y[2]));
    ad=sqrt(pow_2(x[4]-x[1])+pow_2(y[4]-y[1]));
    p=(ab+bd+ad)/2;
    S=sqrt(p*(p-ab)*(p-bd)*(p-ad));
    return S;
}
int max1(int a,int b,int c,int d)
{
    int x=max(a,b);
    x=max(x,c);
    x=max(x,d);
    return x;
}
int main()
{
    int ans=0;
    for(int i=1;i<=n;i++)
    {
        cin>>x[i]>>y[i];
    }
    if(abc()>0)ans++;
    if(bcd()>0)ans++;
    if(acd()>0)ans++;
    if(abd()>0)ans++;
    if(ans==1)ans=0;
    if(ans==2)ans=1;
    if(ans==3)ans=2;
    int maxx=max1(abc(),bcd(),acd(),abd());
    int sum=maxx-(abc()+bcd()+acd()+abd());
    if(ans==4)
    {
        if(sum==maxx)
        {
            ans=3;
        }
        else
            ans=4;
    }
    cout<<ans<<endl;
    return 0;
}
