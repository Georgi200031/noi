#include <iostream>
#include <algorithm>
#define MAXN 9999999
using namespace std;
long long n,key,array[MAXN],p[MAXN];
void solve(int n,int key)
{
    for(int j=1;j<=n;j++)
    {
        int v=key-array[j];
        if(v>0)
        if(p[v]==0)
        p[v]=j;
    }
    for(int i=1;i<=n;i++)
    {
        if(p[array[i]]>0)
        {
            cout<<i<<" "<<p[array[i]]<<endl;
            i=n;
            break;
        }
    }
}
int main()
{
    cin>>n;
    for(int i=1; i<=n; i++)
    {
        cin>>array[i];
    }
    for(int i=1;i<=n;i++)
    {
        p[i]=0;
    }
    cin>>key;
    solve(n,key);
    return 0;
}
