#include <iostream>
#define MAXN 9999999
using namespace std;
int a[MAXN];

void create(int key)
{
     int ans1,ans1_1,ans2_2;
     int check_br=0;
     int l=2,r=4,br=0;
     long long k=2;
     int index=0;
     a[-1]=1;a[0]=2;
     int last_l,last_r;
     for(int i=-1;i<=key*key;i++)
     {
            l++;
            r++;
           // cout<<a[i]<<endl<<endl;

            if(br!=k)
            {
                index++;
                a[index]=l;
                index++;
                a[index]=r;
            }
            if(br==k)
            {
                l--;
                r--;
                br=0;
                l=r+1;
                k=k*2;
                r=l+k;
                index++;
                a[index]=l;
                index++;
                a[index]=r;
            }
            br++;
//cout<<l<<" "<<r<<endl<<endl;
if(l==key)
{
    ans1=a[i];
    check_br++;
}
if(r==key)
{
    ans1=a[i];
    check_br++;
}
 if(a[i]==key)
            {
                ans1_1=l;
                ans2_2=r;
                check_br++;
            }
if(check_br==2)
{
    break;
}
     }
 cout<<ans1<<endl;
 cout<<ans1_1<<" "<<ans2_2<<endl;
}
int main()
{
    int n;
    cin>>n;
    create(n);
    return 0;
}
