#include <iostream>
#include <string.h>
using namespace std;
string a;
string b;
int index;
string aa;
string bb;
string solve(int index)
{
    int t=a.size()-1;
    for(int i=0;i<t;i++)
    {
        for(int j=0;j<b.size();j++)
        {
             if(a[i]==b[j])
             {
                 a[i]=a[t];
                 t--;
             }
        }
    }
    int inx=0;
    for(int i=t-1;i>-1;i--)
    {
        for(int j=1;j<=b.size();j++)
        {
            aa=a[i]+b[j];
            cout<<aa<<endl;
            inx++;
        }
    }
    for(int i=0;i<inx;i++)
    {
        cout<<aa[i]<<endl;
    }
    cout<<endl;
    return aa;
}
int main()
{
    /*
    cin>>a;
    cin>>b;
    cin>>index;
   */
   a="RBAZ";
   b="AR";
   index=14;
    cout<<solve(index)<<endl;
    return 0;
}
