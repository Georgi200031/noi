#include <iostream>
#include <iomanip>
#include <cmath>
using namespace std;
double formula1(double a,double b)
{
    double f=((a-b)/2);
    double h=sqrt(abs((a*a)-(f*f)));
    double S=((a+b)*h)/2;
    return S;
}
double formula2(double a,double b)
{
    double f=((b-a)/2);
    double h=sqrt(abs((a*a)-(f*f)));
    double S=((a+b)*h)/2;
    return S;
}
int main()
{
    double a,b;
    cin>>a>>b;
    if(a==b)
    {
        cout<<fixed<<setprecision(2)<<a*b<<endl;
    }
    if(a>b)
    {
        cout<<fixed<<setprecision(2)<<formula1(a,b)<<endl;
    }
    if(a<b)
    {
        cout<<fixed<<setprecision(2)<<formula2(a,b)<<endl;
    }
    return 0;
}
