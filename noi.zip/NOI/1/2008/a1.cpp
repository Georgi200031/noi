#include <iostream>
using namespace std;
int k=1,index=0;//k-delitel
int e[1001];
void sum(int i,int j)
{
    if(k<j && k%j!=0)
        k=k*j;
    index++;
    e[index]=i;
}
void kk(int k1,int k)
{
    for(int i=2;i<=k1+k;i++)
    {
        if(k1%i==0 && k%i==0)
        {
            k1=k1/i;
            k=k/i;
        }
        if(i>k && i>k1)break;
    }
    cout<<k1<<"/"<<k<<endl;
}
int main()
{
    int a,b;
    cin>>a>>b;
    for(int i=a;i<=b;i++)
        {
            for(int j=i+1;j<=b;j++)
                {
                    sum(i,j);
                }
        }
        int k1=0;
        for(int i=a;i<=b;i++)
        {
            for(int j=i+a;j<=b;j++)
            {
                k1=k1+((k/j)*i);
            }
        }
        cout<<k1<<"/"<<k<<endl;
        kk(k1,k);
    return 0;
}
