#include <iostream>
using namespace std;
int a[10][10];
int used[10];
void cls()
{
    for(int i=1;i<=9;i++)
    used[i]=0;
}
void check1(int x,int y)
{
    int k=0;
    for(int i=1;i<=9;i++)
    {
        if(a[x][i]!=0)
        used[a[x][i]]=1;
        if(a[x][i]==0)k++;
    }
    if(k==1)
    for(int i=1;i<=9;i++)
    {
        if(used[i]==0)
        {
            a[x][y]=i;
        }
    }
    cls();
}
void check2(int x,int y)
{
    int k=0;
    for(int i=1;i<=9;i++)
    {
        if(a[i][y]!=0)
        used[a[i][y]]=1;
        if(a[i][y]==0)k++;
    }
    if(k==1)
    for(int i=1;i<=9;i++)
    {
        if(used[i]==0)
        {
            a[i][y]=i;
        }
    }
    cls();
}
void check3(int i,int j)
{
    int x=i,y=j;
    if(i>=1 && j>=1 && i<=3 && j<=3)
    {
        for(int i=1;i<=3;i++)
        {
            for(int j=1;j<=3;j++)
            {
                if(a[i][j]!=0)
                {
                    used[a[i][j]]=1;
                }
            }
        }
        for(int i=1;i<=9;i++)
        {
            if(used[i]==0)
            {
                a[x][y]=i;
            }
        }
    }
    cls();
    if(i>=1 && j>=4 && i<=3 && j<=6)
    {
        for(int i=1;i<=3;i++)
        {
            for(int j=4;j<=6;j++)
            {
                if(a[i][j]!=0)
                {
                    used[a[i][j]]=1;
                }
            }
        }
        for(int i=1;i<=9;i++)
        {
            if(used[i]==0)
            {
                a[x][y]=i;
            }
        }
    }
    cls();
    if(i>=1 && j>=7 && i<=3 && j<=9)
    {
        for(int i=1;i<=3;i++)
        {
            for(int j=7;j<=9;j++)
            {
                if(a[i][j]!=0)
                {
                    used[a[i][j]]=1;
                }
            }
        }
        for(int i=1;i<=9;i++)
        {
            if(used[i]==0)
            {
                a[x][y]=i;
            }
        }
    }
//------------------------------------------------------
    cls();
    if(i>=4 && j>=1 && i<=6 && j<=3)
    {
        for(int i=4;i<=6;i++)
        {
            for(int j=1;j<=3;j++)
            {
                if(a[i][j]!=0)
                {
                    used[a[i][j]]=1;
                }
            }
        }
        for(int i=1;i<=9;i++)
        {
            if(used[i]==0)
            {
                a[x][y]=i;
            }
        }
    }
    cls();
    if(i>=4 && j>=4 && i<=6 && j<=6)
    {
        for(int i=4;i<=6;i++)
        {
            for(int j=4;j<=6;j++)
            {
                if(a[i][j]!=0)
                {
                    used[a[i][j]]=1;
                }
            }
        }
        for(int i=1;i<=9;i++)
        {
            if(used[i]==0)
            {
                a[x][y]=i;
            }
        }
    }
    cls();
    if(i>=4 && j>=7 && i<=6 && j<=9)
    {
        for(int i=4;i<=6;i++)
        {
            for(int j=7;j<=9;j++)
            {
                if(a[i][j]!=0)
                {
                    used[a[i][j]]=1;
                }
            }
        }
        for(int i=1;i<=9;i++)
        {
            if(used[i]==0)
            {
                a[x][y]=i;
            }
        }
    }
//---------------------------------------------
 cls();
    if(i>=7 && j>=1 && i<=9 && j<=3)
    {
        for(int i=7;i<=9;i++)
        {
            for(int j=1;j<=3;j++)
            {
                if(a[i][j]!=0)
                {
                    used[a[i][j]]=1;
                }
            }
        }
        for(int i=1;i<=9;i++)
        {
            if(used[i]==0)
            {
                a[x][y]=i;
            }
        }
    }
    cls();
    if(i>=7 && j>=4 && i<=9 && j<=6)
    {
        for(int i=7;i<=9;i++)
        {
            for(int j=4;j<=6;j++)
            {
                if(a[i][j]!=0)
                {
                    used[a[i][j]]=1;
                }
            }
        }
        for(int i=1;i<=9;i++)
        {
            if(used[i]==0)
            {
                a[x][y]=i;
            }
        }
    }
    cls();
    if(i>=7 && j>=7 && i<=9 && j<=9)
    {
        for(int i=7;i<=9;i++)
        {
            for(int j=7;j<=9;j++)
            {
                if(a[i][j]!=0)
                {
                    used[a[i][j]]=1;
                }
            }
        }
        for(int i=1;i<=9;i++)
        {
            if(used[i]==0)
            {
                a[x][y]=i;
            }
        }
    }
}
int main()
{
    for(int i=1;i<=9;i++)
    {
        for(int j=1;j<=9;j++)
        {
            cin>>a[i][j];
        }
    }
    for(int i=1;i<=9;i++)
    {
        for(int j=1;j<=9;j++)
        {
            if(a[i][j]==0)
            {
                check1(i,j);
                check2(i,j);
                check3(i,j);
            }
            cls();
        }
    }
    cout<<endl;
    for(int i=1;i<=9;i++)
    {
        for(int j=1;j<=9;j++)
        {
            cout<<a[i][j]<<" ";
        }
        cout<<endl;
    }

    return 0;
}
