#include <iostream>
#define MAXN 9999999
using namespace std;
int step(int n)
{
    int steps=1;
    int a[1001];
    int y;
    int y1;
    a[1]=1;
    a[2]=2;
    int k=2;
    int  result=0;
    while(result==0)
    {
        steps++;
        for(int i=1;i<=k;i++)
        {
            for(int j=i+1;j<=k;j++)
            {
                y=a[i]+a[j];
                y1=a[i]*a[j];
                k++;
                a[k]=y;
                k++;
                a[k]=y1;
                if(y==n || y1==n)
                    {
                        result=steps;
                        i=k;
                    }
                cout<<y<<" "<<y1<<endl;
            }
            cout<<endl<<endl;
        }

    }

    return result;
}
int main()
{
    int n;
    cin>>n;
    cout<<step(n)<<endl;
    return 0;
}
