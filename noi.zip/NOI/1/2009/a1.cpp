#include <iostream>
using namespace std;
bool arr[999999];
long long x[100001],y[1000001];
int main()
{
    int n,n1=0;
    cin>>n;
    for(int i=1;i<=n;i++)
    {
          cin>>x[i]>>y[i];
    }
    n1++;
    int ans=0,maxx=0;
    for(int i=1;i<=n;i++)
    {
        if(n1<y[i])n1=y[i];
        for(int j=x[i];j<=y[i];j++)
        {
            if(arr[j]==1)arr[j]=0;
            else arr[j]=1;
        }
    }
    for(int i=1;i<=n1;i++)
    {
        if(arr[i]==1)
            ans++;
            if(arr[i]==0)
            {
                if(maxx<ans)maxx=ans;
                ans=0;
            }
    }
    cout<<maxx<<endl;
    return 0;
}
